using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{

    public GameObject coinPrefab;

    public float spawnDelay;
    float t = 0;



    // Update is called once per frame
    void Update()
    {
        // AUGMENTE MA VALEUR T DE 1 PAR SECONDE
        t += 1 * Time.deltaTime;



        if (t > spawnDelay)
        {
            Vector3 posToInstantiate = new Vector3(Random.Range(-3.5f, 3.5f), 1.15f , transform.position.z);
            // SPAWN
            Instantiate(coinPrefab, posToInstantiate, Quaternion.identity);

            // RESET TIMER
            t = 0; 
        }



    }
}
