using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public Text scoreText;

    private float score;

    private void Start()
    {
        scoreText.text = score.ToString();
    }


    public void AddScore(float valueToAdd)
    {
        // AUGMENTER LE SCORE
        score += valueToAdd;

        // METTRE A JOUR L'UI
        scoreText.text = score.ToString();
    }


}
