using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    private int health;

    public Text textVie;

    public GameObject screenLoose;

    private void Start()
    {


        health = 10;

        // UPDATE UI
        textVie.text = "Vie : " + health.ToString();
    }

    public void PerdrePointDeVie()
    {
        // PERD 1 PV
        health--;


        // UPDATE TEXT
        textVie.text = "Vie : " + health.ToString();


        // SI PLUS DE PV
        if(health <= 0)
        {
            // ON A PERDU
            Loose();
        }
    }


    void Loose()
    {
        // METTRE LE JEU EN PAUSE
        Time.timeScale = 0;

        // PERDRE
        screenLoose.SetActive(true);

    }


    public void PlayAgain()
    {
        SceneManager.LoadScene(0);
        // METTRE LE JEU EN PAUSE
        Time.timeScale = 1;

    }

}
