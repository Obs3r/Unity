using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerEnvironnement : MonoBehaviour
{

    private void OnTriggerExit(Collider other)
    {
        if(other.tag == "Player")
        {
            Vector3 newPos = new Vector3(0, 0, transform.position.z + 77);

            StartCoroutine(ChangerPosition(newPos));

        }
    }

    IEnumerator ChangerPosition(Vector3 _newPos)
    {
        yield return new WaitForSeconds(2);

        transform.parent.position = _newPos;

    }
}
