using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public float value = 10;
    public float rotationSpeed = 360;


    private void Start()
    {
        Destroy(gameObject, 10);
    }

    private void Update()
    {
        // ROTATION SUR PLACE
        transform.Rotate(0, rotationSpeed * Time.deltaTime, 0);
    }

    // QUAND UN OBJET RENTRE DANS LE TRIGGER
    private void OnTriggerEnter(Collider player)
    {

        if (player.transform.tag == "Player")
        {

            Destroy(gameObject);

            //player.GetComponent<Score>().score += value;
            player.GetComponent<Score>().AddScore(value);

        }

    }
}
