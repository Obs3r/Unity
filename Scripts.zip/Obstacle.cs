using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour
{

    public GameObject particle;

    private void Start()
    {
        Destroy(gameObject, 10);
    }
    private void OnTriggerEnter(Collider player)
    {
        if(player.transform.tag == "Player")
        {

            player.GetComponent<Health>().PerdrePointDeVie();


            GameObject go = Instantiate(particle, transform.position, Quaternion.identity);
            Destroy(go, 10f);



            Destroy(gameObject);
        }
    }
}
